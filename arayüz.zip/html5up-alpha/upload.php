


<?php include ("header.php"); ?>
			<!-- Header -->
			

			<!-- Banner -->
				<section id="banner">
					<h2>Choose the What You Want to Upload</h2>
					<p></p>
					<ul class="actions special">
						<li><a href="upload_music.php" class="button">Upload Music</a></li>
						<li><a href="upload_lyric.php" class="button">Upload Lyric</a></li>
                        <li><a href="upload_sound.php" class="button">Upload Sound</a></li>

					</ul>
				</section>

			

			<!-- Footer -->
<?php include ("footer.php");?>