<?php include("header2.php");	?>
			<!-- Main -->
				<section id="main" class="container medium">
					<header>
						<br>
						<br>
						<h2>ADMIN LOGIN</h2>
						<p></p>
						
					</header>
					
					<div class="box">
						<form method="post" action="admin.php">
							<div class="row gtr-50 gtr-uniform">
								<div class="col-6 col-12-mobilep">
									<input type="text" name="name" id="name" value="" placeholder="Username"/>
								</div>
								<div class="col-6 col-12-mobilep">
									<input type="password" name="txtPassword" id="email" value="" placeholder="password" />
								</div>
							
								
								<div class="col-12">
									<br>
									<ul class="actions special">
										
										<li><input type="submit" value="Login" /></li>
									</ul>
								</div>
							</div>
						</form>
					</div>
				</section>

			<!-- Footer -->
			
<?php include("footer.php");	?>




